const policies = require("./assets/policies.json")
const claims = require('./assets/claims.json')

module.exports = () => ({
        policies,
        claims
    }
);
